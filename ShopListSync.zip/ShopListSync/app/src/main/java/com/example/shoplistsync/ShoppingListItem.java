package com.example.shoplistsync;

public class ShoppingListItem
{
    String id;
    String item;
    int quantity;
    String notes;
}
