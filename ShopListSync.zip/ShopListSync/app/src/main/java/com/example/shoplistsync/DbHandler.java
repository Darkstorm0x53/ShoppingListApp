package com.example.shoplistsync;

import android.database.sqlite.SQLiteOpenHelper;

public class DbHandler extends SQLiteOpenHelper
{

}
