package com.example.shoplistsync;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;


public class AddItem extends AppCompatActivity
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.frag_item_entry);
    }
}