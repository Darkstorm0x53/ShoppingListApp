package com.example.shoplistsync;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


public class DbHandler extends SQLiteOpenHelper
{
    // Db items
    private static final int DB_VERSION = 1;
    private String DB_NAME = "listDb";
    private static final String COLUMN_NAME = "item";
    private static final String ITEM_ID = "id";
    private static int ITEM_QUANTITY;
    private static final String ITEM_INFO = "info";
    private static final String PATH = "/storage/emulated/0/Documents";



    public DbHandler(Context context) {
        super(context, "database_name.db", null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db)
    {
        String CREATE_COLUMN = "CREATE TABLE " + COLUMN_NAME + "("
                + ITEM_ID + ")" + ITEM_QUANTITY + ITEM_INFO;

        db.execSQL(CREATE_COLUMN);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
    {
        db.execSQL("DROP TABLE IF EXISTS" + COLUMN_NAME);
        onCreate(db);

    }
}
